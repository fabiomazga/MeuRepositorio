package Empresa;

import java.util.Scanner;

public class TestaFuncionario {
	
	public static void main(String[] args) {
		
		
	Gerente g1 = new Gerente();
	g1.setNome("Juliana Alves");
	g1.setMesAdimicao(07);
	g1.setAnoAdimicao(2017);
	g1.setSalario(20000);
	
	Gerente g2 = new Gerente();
	g2.setNome("Bento Albino");
	g2.setMesAdimicao(03);
	g2.setAnoAdimicao(2014);
	g2.setSalario(20000);
	
	Secretario s1 = new Secretario();
	s1.setNome("Jorge Carvalho");
	s1.setMesAdimicao(01);
	s1.setAnoAdimicao(2018);
	s1.setSalario(7000);
	
	Secretario s2 = new Secretario();
	s2.setNome("Maria Souza");
	s2.setMesAdimicao(12);
	s2.setAnoAdimicao(2015);
	s2.setSalario(7000);
	
	Vendedor v1 = new Vendedor();
	v1.setNome("Ana Silva");
	v1.setMesAdimicao(12);
	v1.setAnoAdimicao(2021);
	v1.setSalario(12000);
	v1.setVenda122021(5200);
	v1.setVenda012022(4000);
	v1.setVenda022022(4200);
	v1.setVenda032022(5850);
	v1.setVenda042022(7000);
	
	Vendedor v2 = new Vendedor();
	v2.setNome("Joao Mendes");
	v2.setMesAdimicao(12);
	v2.setAnoAdimicao(2021);
	v2.setSalario(12000);
	v2.setVenda122021(3400);
	v2.setVenda012022(7700);
	v2.setVenda022022(5000);
	v2.setVenda032022(5900);
	v2.setVenda042022(6500);
	
	
	
	
	//Escolha o mês
	
	Scanner entrada = new Scanner(System.in);
	System.out.println("Escolha a opcao do mes de apuracao: ");
	System.out.println("1 - 12/2021");
	System.out.println("2 - 01/2022");
	System.out.println("3 - 02/2022");
	System.out.println("4 - 03/2022");
	System.out.println("5 - 04/2022");
	 int numero = entrada.nextInt();
	 switch (numero) {
     case 1:
       System.out.println("O periodo escolhido foi 12/2021.");
   	System.out.println("____________________Funcionarios____________________");
   	System.out.println("Nome: " + g1.getNome() + " recebe no total R$ " + g1.salarioTotal());
   	System.out.println("Nome: " + g2.getNome() + " recebe no total R$ " + g2.salarioTotal());
   	System.out.println("Nome: " + v1.getNome() + " recebe no total R$ " + v1.salarioTotal122021());
   	System.out.println("Nome: " + v2.getNome() + " recebe no total R$ " + v2.salarioTotal122021());
   	System.out.println("Nome: " + s1.getNome() + " recebe no total R$ " + s1.salarioTotal());
   	System.out.println("Nome: " + s2.getNome() + " recebe no total R$ " + s2.salarioTotal());
   	System.out.println("O total gasto pela empresa com funcionarios em 12/2021 foi de R$ " + (g1.salarioTotal()+ g2.salarioTotal()+v1.salarioTotal122021()+v2.salarioTotal122021()+s1.salarioTotal()+s2.salarioTotal()));
   	System.out.println("O total gasto pela empresa com beneficios de funcionarios em 12/2021 foi de R$" + ((s1.getSalario()*0.2)+ (s2.getSalario()*0.2)+ (v1.venda122021*0.3)+(v2.venda122021*0.3)));
   	
    double maiorSalario122021 = 0;
    maiorSalario122021 = Math.max(g1.salarioTotal(), g2.salarioTotal());
    maiorSalario122021 = Math.max(maiorSalario122021, v1.salarioTotal122021());
    maiorSalario122021 = Math.max(maiorSalario122021, v2.salarioTotal122021());
    maiorSalario122021 = Math.max(maiorSalario122021, s1.salarioTotal());
    maiorSalario122021 = Math.max(maiorSalario122021, s2.salarioTotal());
    System.out.println("O maior salario pago em 12/2021 foi de R$ " + maiorSalario122021);
    
    double maiorBeneficio122021=0;
    maiorBeneficio122021 = Math.max((s1.getSalario()*0.2),(s2.getSalario()*0.2));
    maiorBeneficio122021 = Math.max(maiorBeneficio122021, (v1.venda122021*0.3));
    maiorBeneficio122021 = Math.max(maiorBeneficio122021, (v2.venda122021*0.3));
    System.out.println("O maior beneficio pago em 12/2021 foi de R$ " + maiorBeneficio122021);
    
    double maiorVendedor122021 =0;
    maiorVendedor122021 = Math.max(v1.venda122021, v2.venda122021);
    if(maiorVendedor122021 == v1.venda122021) {
    	System.out.println("O maior vendedor de 12/2021 foi : "+ v1.getNome());
    }else {
    	System.out.println("O maior vendedor de 12/2021 foi : "+ v2.getNome());
    }


       break;
     case 2:
       System.out.println("O periodo escolhido foi 01/2022.");
       System.out.println("____________________Funcionarios____________________");
   	System.out.println("Nome: " + g1.getNome() + " recebe no total R$ " + g1.salarioTotal());
   	System.out.println("Nome: " + g2.getNome() + " recebe no total R$ " + g2.salarioTotal());
   	System.out.println("Nome: " + v1.getNome() + " recebe no total R$ " + v1.salarioTotal012022());
   	System.out.println("Nome: " + v2.getNome() + " recebe no total R$ " + v2.salarioTotal012022());
   	System.out.println("Nome: " + s1.getNome() + " recebe no total R$ " + s1.salarioTotal());
   	System.out.println("Nome: " + s2.getNome() + " recebe no total R$ " + s2.salarioTotal());
   	System.out.println("O total gasto pela empresa com funcionarios em 01/2022 foi de R$ " + (g1.salarioTotal()+ g2.salarioTotal()+v1.salarioTotal012022()+v2.salarioTotal012022()+s1.salarioTotal()+s2.salarioTotal()));
   	System.out.println("O total gasto pela empresa com beneficios de funcionarios em 01/2022 foi de R$" + ((s1.getSalario()*0.2)+ (s2.getSalario()*0.2)+ (v1.venda012022*0.3)+(v2.venda012022*0.3)));
   	
    double maiorSalario012022 = 0;
    maiorSalario012022 = Math.max(g1.salarioTotal(), g2.salarioTotal());
    maiorSalario012022 = Math.max(maiorSalario012022, v1.salarioTotal012022());
    maiorSalario012022 = Math.max(maiorSalario012022, v2.salarioTotal012022());
    maiorSalario012022 = Math.max(maiorSalario012022, s1.salarioTotal());
    maiorSalario012022 = Math.max(maiorSalario012022, s2.salarioTotal());
    System.out.println("O maior salario pago em 12/2021 foi de R$ " + maiorSalario012022);
    
    double maiorBeneficio012022=0;
    maiorBeneficio012022 = Math.max((s1.getSalario()*0.2),(s2.getSalario()*0.2));
    maiorBeneficio012022 = Math.max(maiorBeneficio012022, (v1.venda012022*0.3));
    maiorBeneficio012022 = Math.max(maiorBeneficio012022, (v2.venda012022*0.3));
    System.out.println("O maior beneficio pago em 01/2022 foi de R$ " + maiorBeneficio012022);
    
    double maiorVendedor012022 =0;
    maiorVendedor012022 = Math.max(v1.venda012022, v2.venda012022);
    if(maiorVendedor012022 == v1.venda012022) {
    	System.out.println("O maior vendedor de 01/2022 foi : "+ v1.getNome());
    }else {
    	System.out.println("O maior vendedor de 01/2022 foi : "+ v2.getNome());
    }
   	
       break;
     case 3:
       System.out.println("O periodo escolhido foi 02/2022.");
       System.out.println("____________________Funcionarios____________________");
   	System.out.println("Nome: " + g1.getNome() + " recebe no total R$ " + g1.salarioTotal());
   	System.out.println("Nome: " + g2.getNome() + " recebe no total R$ " + g2.salarioTotal());
   	System.out.println("Nome: " + v1.getNome() + " recebe no total R$ " + v1.salarioTotal022022());
   	System.out.println("Nome: " + v2.getNome() + " recebe no total R$ " + v2.salarioTotal022022());
   	System.out.println("Nome: " + s1.getNome() + " recebe no total R$ " + s1.salarioTotal());
   	System.out.println("Nome: " + s2.getNome() + " recebe no total R$ " + s2.salarioTotal());
   	System.out.println("O total gasto pela empresa com funcionarios em 02/2022 foi de R$ " + (g1.salarioTotal()+ g2.salarioTotal()+v1.salarioTotal022022()+v2.salarioTotal022022()+s1.salarioTotal()+s2.salarioTotal()));
   	System.out.println("O total gasto pela empresa com beneficios de funcionarios em 02/2022 foi de R$" + ((s1.getSalario()*0.2)+ (s2.getSalario()*0.2)+ (v1.venda022022*0.3)+(v2.venda022022*0.3)));
   	
    double maiorSalario022022 = 0;
    maiorSalario022022 = Math.max(g1.salarioTotal(), g2.salarioTotal());
    maiorSalario022022 = Math.max(maiorSalario022022, v1.salarioTotal022022());
    maiorSalario022022 = Math.max(maiorSalario022022, v2.salarioTotal022022());
    maiorSalario022022 = Math.max(maiorSalario022022, s1.salarioTotal());
    maiorSalario022022 = Math.max(maiorSalario022022, s2.salarioTotal());
    System.out.println("O maior salario pago em 12/2021 foi de R$ " + maiorSalario022022);
    
    double maiorBeneficio022022=0;
    maiorBeneficio022022 = Math.max((s1.getSalario()*0.2),(s2.getSalario()*0.2));
    maiorBeneficio022022 = Math.max(maiorBeneficio022022, (v1.venda022022*0.3));
    maiorBeneficio022022 = Math.max(maiorBeneficio022022, (v2.venda022022*0.3));
    System.out.println("O maior beneficio pago em 02/2022 foi de R$ " + maiorBeneficio022022);
    
    double maiorVendedor022022 =0;
    maiorVendedor022022 = Math.max(v1.venda022022, v2.venda022022);
    if(maiorVendedor022022 == v1.venda022022) {
    	System.out.println("O maior vendedor de 02/2022 foi : "+ v1.getNome());
    }else {
    	System.out.println("O maior vendedor de 02/2022 foi : "+ v2.getNome());
    }
   	
       break;
     case 4:
       System.out.println("O periodo escolhido foi 03/2022.");
       System.out.println("____________________Funcionarios____________________");
   	System.out.println("Nome: " + g1.getNome() + " recebe no total R$ " + g1.salarioTotal());
   	System.out.println("Nome: " + g2.getNome() + " recebe no total R$ " + g2.salarioTotal());
   	System.out.println("Nome: " + v1.getNome() + " recebe no total R$ " + v1.salarioTotal032022());
   	System.out.println("Nome: " + v2.getNome() + " recebe no total R$ " + v2.salarioTotal032022());
   	System.out.println("Nome: " + s1.getNome() + " recebe no total R$ " + s1.salarioTotal());
   	System.out.println("Nome: " + s2.getNome() + " recebe no total R$ " + s2.salarioTotal());
   	System.out.println("O total gasto pela empresa com funcionarios em 03/2022 foi de R$ " + (g1.salarioTotal()+ g2.salarioTotal()+v1.salarioTotal032022()+v2.salarioTotal032022()+s1.salarioTotal()+s2.salarioTotal()));
   	System.out.println("O total gasto pela empresa com beneficios de funcionarios em 03/2022 foi de R$" + ((s1.getSalario()*0.2)+ (s2.getSalario()*0.2)+ (v1.venda032022*0.3)+(v2.venda032022*0.3)));
   	
    double maiorSalario032022 = 0;
    maiorSalario032022 = Math.max(g1.salarioTotal(), g2.salarioTotal());
    maiorSalario032022 = Math.max(maiorSalario032022, v1.salarioTotal032022());
    maiorSalario032022 = Math.max(maiorSalario032022, v2.salarioTotal032022());
    maiorSalario032022 = Math.max(maiorSalario032022, s1.salarioTotal());
    maiorSalario032022 = Math.max(maiorSalario032022, s2.salarioTotal());
    System.out.println("O maior salario pago em 12/2021 foi de R$ " + maiorSalario032022);
    
    double maiorBeneficio032022=0;
    maiorBeneficio032022 = Math.max((s1.getSalario()*0.2),(s2.getSalario()*0.2));
    maiorBeneficio032022 = Math.max(maiorBeneficio032022, (v1.venda032022*0.3));
    maiorBeneficio032022 = Math.max(maiorBeneficio032022, (v2.venda032022*0.3));
    System.out.println("O maior beneficio pago em 03/2022 foi de R$ " + maiorBeneficio032022);
    
    double maiorVendedor032022 =0;
    maiorVendedor032022 = Math.max(v1.venda032022, v2.venda032022);
    if(maiorVendedor032022 == v1.venda032022) {
    	System.out.println("O maior vendedor de 03/2022 foi : "+ v1.getNome());
    }else {
    	System.out.println("O maior vendedor de 03/2022 foi : "+ v2.getNome());
    }
   	
       break;
     case 5:
       System.out.println("O periodo escolhido foi 04/2022.");
       System.out.println("____________________Funcionarios____________________");
   	System.out.println("Nome: " + g1.getNome() + " recebe no total R$ " + g1.salarioTotal());
   	System.out.println("Nome: " + g2.getNome() + " recebe no total R$ " + g2.salarioTotal());
   	System.out.println("Nome: " + v1.getNome() + " recebe no total R$ " + v1.salarioTotal042022());
   	System.out.println("Nome: " + v2.getNome() + " recebe no total R$ " + v2.salarioTotal042022());
   	System.out.println("Nome: " + s1.getNome() + " recebe no total R$ " + s1.salarioTotal());
   	System.out.println("Nome: " + s2.getNome() + " recebe no total R$ " + s2.salarioTotal());
   	System.out.println("O total gasto pela empresa com funcionarios em 04/2022 foi de R$ " + (g1.salarioTotal()+ g2.salarioTotal()+v1.salarioTotal042022()+v2.salarioTotal042022()+s1.salarioTotal()+s2.salarioTotal()));
   	System.out.println("O total pago com beneficios em 04/2022 foi de R$" + (((s1.salarioTotal()/1.2)*0.2)+((s2.salarioTotal()/1.2)*0.2)+((v1.salarioTotal042022()/1.3)*0.3)+((v2.salarioTotal042022()/1.3)*0.3)));
   	System.out.println("O total gasto pela empresa com beneficios de funcionarios em 04/2022 foi de R$" + ((s1.getSalario()*0.2)+ (s2.getSalario()*0.2)+ (v1.venda042022*0.3)+(v2.venda042022*0.3)));  
   	
    double maiorSalario042022 = 0;
    maiorSalario042022 = Math.max(g1.salarioTotal(), g2.salarioTotal());
    maiorSalario042022 = Math.max(maiorSalario042022, v1.salarioTotal042022());
    maiorSalario042022 = Math.max(maiorSalario042022, v2.salarioTotal042022());
    maiorSalario042022 = Math.max(maiorSalario042022, s1.salarioTotal());
    maiorSalario042022 = Math.max(maiorSalario042022, s2.salarioTotal());
    System.out.println("O maior salario pago em 12/2021 foi de R$ " + maiorSalario042022);
    
    double maiorBeneficio042022=0;
    maiorBeneficio042022 = Math.max((s1.getSalario()*0.2),(s2.getSalario()*0.2));
    maiorBeneficio042022 = Math.max(maiorBeneficio042022, (v1.venda042022*0.3));
    maiorBeneficio042022 = Math.max(maiorBeneficio042022, (v2.venda042022*0.3));
    System.out.println("O maior beneficio pago em 04/2022 foi de R$ " + maiorBeneficio042022);
    
    double maiorVendedor042022 =0;
    maiorVendedor042022 = Math.max(v1.venda042022, v2.venda042022);
    if(maiorVendedor042022 == v1.venda042022) {
    	System.out.println("O maior vendedor de 04/2022 foi : "+ v1.getNome());
    }else {
    	System.out.println("O maior vendedor de 04/2022 foi : "+ v2.getNome());
    }
   	
   	break;
     default:
       System.out.println("O número escolhido é inválido! Digite um número entre 1 a 5.");
	
	
	}
	
	

}

}