package Empresa;

public class Gerente extends Funcionario {
	
	public double salarioTotal() {
		return this.getSalario()+ 3000 * tempoServico();
	}

}
