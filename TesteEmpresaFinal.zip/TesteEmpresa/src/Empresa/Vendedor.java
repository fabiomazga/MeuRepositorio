package Empresa;

public class Vendedor extends Funcionario{
	double venda122021;
	double venda012022;
	double venda022022;
	double venda032022;
	double venda042022;
	public double getVenda122021() {
		return venda122021;
	}
	public void setVenda122021(int venda122021) {
		this.venda122021 = venda122021;
	}
	public double getVenda012022() {
		return venda012022;
	}
	public void setVenda012022(int venda012022) {
		this.venda012022 = venda012022;
	}
	public double getVenda022022() {
		return venda022022;
	}
	public void setVenda022022(int venda022022) {
		this.venda022022 = venda022022;
	}
	public double getVenda032022() {
		return venda032022;
	}
	public void setVenda032022(int venda032022) {
		this.venda032022 = venda032022;
	}
	public double getVenda042022() {
		return venda042022;
	}
	public void setVenda042022(int venda042022) {
		this.venda042022 = venda042022;
	}
	
	public double salarioTotal122021() {
	    return this.getSalario()+ 3000 * tempoServico() + this.venda122021*0.3;
	}
    public double salarioTotal012022() {
		return this.getSalario()+ 3000 * tempoServico() + this.venda012022*0.3;
	}
    public double salarioTotal022022() {
 		return this.getSalario()+ 3000 * tempoServico() + this.venda022022*0.3;
 	}
    public double salarioTotal032022() {
 		return this.getSalario()+ 3000 * tempoServico() + this.venda032022*0.3;
 	}
    public double salarioTotal042022() {
 		return this.getSalario()+ 3000 * tempoServico() + this.venda042022*0.3;
 	}
  

}
