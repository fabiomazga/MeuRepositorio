package Empresa;

public class Secretario extends Funcionario{
	
	public double salarioTotal() {
		return (this.getSalario()+ 1000 * tempoServico())*1.2;
	}

}
