package Empresa;

public class Funcionario {
	 
	 private String nome;
	 private int mesAdimicao;
	 private int anoAdimicao;
	 private double salario;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getMesAdimicao() {
		return mesAdimicao;
	}
	public void setMesAdimicao(int mesAdimicao) {
		this.mesAdimicao = mesAdimicao;
	}
	public int getAnoAdimicao() {
		return anoAdimicao;
	}
	public void setAnoAdimicao(int anoAdimicao) {
		this.anoAdimicao = anoAdimicao;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	public double salarioTotal() {
		return this.salario;
	}
	public int tempoServico () {
		int anos = 0;
		if(this.getMesAdimicao()<11) {
		anos = 2022 - this.getAnoAdimicao();
		}else {
		anos = 2022 - this.getAnoAdimicao()-1;
		}
		return anos;
		
	}

}
